exports.whitelistOrigins = [
  'https://www.freecodecamp.dev',
  'https://www.freecodecamp.org',
  'https://beta.freecodecamp.dev',
  'https://beta.freecodecamp.org',
  'https://chinese.freecodecamp.dev',
  'https://chinese.freecodecamp.org'
];
